# PSI_AMSI
--------------------------------

# Descrição do projeto
--------------------------------

No âmbito da unidade curricular de Acesso Movel de Sistemas Informação do 3º Semestre do Curso TeSP de Programação de Sistemas de Informação do Instituto Politécnico de Leiria, foi criada a aplicação Android pertencente ao projeto “CicloDias”, que consiste na elaboração de uma aplicação que monitoriza a atividade física do utilizador.

O projeto é comum entre várias disciplinas, mas as fases que traçam este projeto são divididas entre todas, conforme a sua pertinência.

## Membros da Equipa

* Iuri Carrasqueiro Nº 2201127
* Gabriel Silva Nº 2201133

# Credenciais de Acesso

## Utilizador

Username: marioviana

Password: 123456789

## Link do Website

http://ciclodias.duckdns.org/

## Link do PhpMyAdmin

http://ciclodias.duckdns.org/phpmyadmin/

Username: marioviana

Password: ciclodiasamsi2022


## Imagem da instituição

![IPL](docs/logoipl.png)