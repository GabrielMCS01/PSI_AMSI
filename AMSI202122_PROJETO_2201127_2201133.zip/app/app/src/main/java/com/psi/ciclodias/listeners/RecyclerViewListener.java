package com.psi.ciclodias.listeners;

import android.view.View;

public interface RecyclerViewListener {
    public void recyclerViewListClicked(View v, int position);
}
