package com.psi.ciclodias.listeners;

public interface RotaListener {
    void setRoute();
}
