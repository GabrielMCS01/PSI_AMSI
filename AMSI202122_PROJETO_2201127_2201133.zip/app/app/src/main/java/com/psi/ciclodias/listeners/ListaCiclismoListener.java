package com.psi.ciclodias.listeners;

import com.psi.ciclodias.model.Ciclismo;

import java.util.ArrayList;

public interface ListaCiclismoListener {
    void onRefreshListaLivros(ArrayList<Ciclismo> lista);
}
