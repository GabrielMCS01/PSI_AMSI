package com.psi.ciclodias.listeners;

public interface PublicacaoListener {
    void criarPublicacao(final String mensagem);
}
