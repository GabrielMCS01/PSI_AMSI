package com.psi.ciclodias.listeners;

public interface RegistoListener {
    void createUser(Boolean success);
}
