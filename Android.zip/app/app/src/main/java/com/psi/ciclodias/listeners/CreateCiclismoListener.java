package com.psi.ciclodias.listeners;

import com.psi.ciclodias.model.Ciclismo;

public interface CreateCiclismoListener {
    void createCiclismo(Ciclismo ciclismo);
}
