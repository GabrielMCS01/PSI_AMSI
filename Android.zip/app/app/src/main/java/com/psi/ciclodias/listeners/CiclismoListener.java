package com.psi.ciclodias.listeners;

public interface CiclismoListener {
    void editCiclismo(Boolean success);
    void removeCiclismo(Boolean success);
}
